4.02.1+1
--------

* map `functor () ->` to `functor * ->` like OCaml
* fix hanging problem in the toplevel

4.02.0+2
--------

* raise an error when passing "with type M.t := ..." to OCaml
* Make scripts insensitive to `CDPATH`
* fix build when ocamlopt is not available
* fix the default value of `PKGDIR`

4.02.0+1
--------

* support the `M()` syntax
* support for extensible types
* support the `match ... with exception ...` syntax
