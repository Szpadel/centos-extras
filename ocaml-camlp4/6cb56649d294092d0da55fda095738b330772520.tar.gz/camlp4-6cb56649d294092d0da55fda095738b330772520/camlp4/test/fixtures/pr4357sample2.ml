#default_quotation "sample";;
let u = "Hello";;
let s = <<u>>;;
let s = <:sample<u>>;;
print_string s
