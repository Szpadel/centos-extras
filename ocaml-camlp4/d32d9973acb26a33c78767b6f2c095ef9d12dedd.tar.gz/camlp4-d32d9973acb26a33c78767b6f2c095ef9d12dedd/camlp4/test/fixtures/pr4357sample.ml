let u = "Hello";;
let s = <:sample<u>>;;
print_string s
